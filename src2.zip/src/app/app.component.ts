import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'sai';
  loc:string;
  course:any[]
  emp={"fname":"vsk","lname":"D","age":"22"}
  constructor(){
    this.loc="Vja"
    this.course=["java","oracle"]
  }
  ngOnInit(){
    
  }
}