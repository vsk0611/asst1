import { App1genderPipe } from './app1gender.pipe';

describe('App1genderPipe', () => {
  it('create an instance', () => {
    const pipe = new App1genderPipe();
    expect(pipe).toBeTruthy();
  });
});
