import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app1',
  templateUrl: './app1.component.html',
  styleUrls: ['./app1.component.css']
})
export class app1Component implements OnInit {
  rows=3;
  emp=[
    {id:101,fname:"sai",loc:"vja",sal:5673.738,date:new Date(),gender:1},
    {id:102,fname:"krishna",loc:"pune",sal:2673.738,date:new Date(),gender:1},
    {id:103,fname:"vsk",loc:"wg",sal:3673.738,date:new Date(),gender:2},
    {id:104,fname:"krish",loc:"hyd",sal:4673.738,date:new Date(),gender:2},
    {id:105,fname:"sk",loc:"india",sal:1673.738,date:new Date(),gender:3}
  ]
  constructor() { }
  ngOnInit(): void {
  }
}
